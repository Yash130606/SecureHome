// lib/screens/camera/pi_camera_settings_screen.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/app_colors.dart';
import '../../core/app_text.dart';
import '../../providers/app_provider.dart'; // adjust to your actual Pi provider path
import '../../widgets/settings_row.dart';
import '../../providers/auth_provider.dart';
import '../../widgets/status_badge.dart';

class PiCameraSettingsScreen extends StatefulWidget {
  const PiCameraSettingsScreen({super.key});

  @override
  State<PiCameraSettingsScreen> createState() => _PiCameraSettingsScreenState();
}

class _PiCameraSettingsScreenState extends State<PiCameraSettingsScreen> {
  bool _checkingFirmware = false;
  bool _rebooting = false;

  // ── Detection Sensitivity (synced with Pi) ──────────────────────────────
  // 1 = Low, 2 = Medium, 3 = High
  double _sensitivityValue = 2.0;

  String _sensitivityLabel(double v) {
    if (v <= 1) return 'Low';
    if (v <= 2) return 'Medium';
    return 'High';
  }

  @override
  void initState() {
    super.initState();
    // Pull current sensitivity from Pi provider on open
    final pi = context.read<PiProvider>();
    _sensitivityValue = _sensitivityFromProvider(pi.sensitivity);
  }

  double _sensitivityFromProvider(String? s) {
    switch (s) {
      case 'low':
        return 1.0;
      case 'high':
        return 3.0;
      default:
        return 2.0;
    }
  }

  String _sensitivityToProvider(double v) {
    if (v <= 1) return 'low';
    if (v <= 2) return 'medium';
    return 'high';
  }

  @override
  Widget build(BuildContext context) {
    final pi = context.watch<PiProvider>();

    return Scaffold(
      backgroundColor: AppColors.bg,
      appBar: AppBar(
        title: Text('Pi Camera', style: AppText.h3()),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded, size: 18),
          onPressed: () => Navigator.pop(context),
        ),
        actions: [
          const StatusBadge(isOnline: true),
          const SizedBox(width: 16),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          // ── Preview card ─────────────────────────────────────────────────
          Container(
            height: 180,
            decoration: BoxDecoration(
              color: const Color(0xFF0A0A1A),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(
                  color: AppColors.brand.withOpacity(0.4), width: 1.5),
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(16),
              child: Stack(
                alignment: Alignment.center,
                children: [
                  // scan-line texture
                  CustomPaint(
                    size: const Size(double.infinity, 180),
                    painter: _ScanLinePainter(),
                  ),
                  Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                        padding: const EdgeInsets.all(14),
                        decoration: BoxDecoration(
                          color: AppColors.brand.withOpacity(0.15),
                          shape: BoxShape.circle,
                          border: Border.all(
                              color: AppColors.brand.withOpacity(0.3)),
                        ),
                        child: Icon(Icons.videocam,
                            color: AppColors.brand, size: 28),
                      ),
                      const SizedBox(height: 8),
                      Text('Pi Camera — Live',
                          style: AppText.bodyS(color: Colors.white54)),
                    ],
                  ),
                  Positioned(
                    top: 10,
                    left: 12,
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 7, vertical: 3),
                      decoration: BoxDecoration(
                          color: const Color(0xFFD32F2F),
                          borderRadius: BorderRadius.circular(5)),
                      child: const Text('LIVE',
                          style: TextStyle(
                              color: Colors.white,
                              fontSize: 9,
                              fontWeight: FontWeight.w800,
                              letterSpacing: 0.5)),
                    ),
                  ),
                  Positioned(
                    bottom: 10,
                    right: 12,
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 8, vertical: 4),
                      decoration: BoxDecoration(
                          color: Colors.black54,
                          borderRadius: BorderRadius.circular(6)),
                      child: Text('Tap for live view',
                          style: AppText.label(size: 10)),
                    ),
                  ),
                ],
              ),
            ),
          ),

          const SizedBox(height: 24),

          // ── General ──────────────────────────────────────────────────────
          SettingSection(title: 'General', children: [
            SettingSwitchRow(
              label: 'Camera On/Off',
              subtitle: 'Enable or disable the Pi camera stream',
              icon: Icons.power_settings_new,
              value: pi.isStreaming,
              onChanged: (v) => pi.setStreaming(v),
            ),
            SettingSwitchRow(
              label: 'Motion Detection',
              icon: Icons.directions_run,
              value: pi.motionDetection,
              onChanged: (v) => pi.setMotionDetection(v),
            ),
            SettingSwitchRow(
              label: 'Night Vision / IR',
              subtitle: 'Toggle infrared LEDs for low-light',
              icon: Icons.nightlight_round,
              value: pi.nightVision,
              onChanged: (v) => pi.setNightVision(v),
            ),
            SettingSwitchRow(
              label: 'Audio Recording',
              icon: Icons.mic_outlined,
              value: pi.audioRecording,
              onChanged: (v) => pi.setAudioRecording(v),
            ),
          ]),

          const SizedBox(height: 20),

          // ── AI Controls ───────────────────────────────────────────────────
          SettingSection(title: 'AI Detection', children: [
            SettingSwitchRow(
              label: 'YOLO Object Detection',
              subtitle: 'Real-time object detection via YOLOv8',
              icon: Icons.auto_awesome,
              value: pi.yoloEnabled,
              onChanged: (v) => pi.setYolo(v),
            ),
            SettingSwitchRow(
              label: 'Face Recognition',
              subtitle: 'Identify known faces from your database',
              icon: Icons.face_outlined,
              value: pi.faceRecognition,
              onChanged: (v) => pi.setFaceRecognition(v),
            ),
            SettingSwitchRow(
              label: 'Person Detection Alerts',
              icon: Icons.person_outline,
              value: pi.personAlerts,
              onChanged: (v) => pi.setPersonAlerts(v),
            ),
            SettingSwitchRow(
              label: 'Motion Alerts',
              icon: Icons.notifications_outlined,
              value: pi.motionAlerts,
              onChanged: (v) => pi.setMotionAlerts(v),
            ),
            // ── Sensitivity slider ──────────────────────────────────────
            SettingSliderRow(
              label: 'Detection Sensitivity',
              icon: Icons.tune,
              value: _sensitivityValue,
              min: 1,
              max: 3,
              divisions: 2,
              valueLabel: _sensitivityLabel,
              onChanged: (v) {
                setState(() => _sensitivityValue = v);
                pi.setSensitivity(_sensitivityToProvider(v));
              },
            ),
          ]),

          const SizedBox(height: 20),

          // ── Stream Settings ───────────────────────────────────────────────
          SettingSection(title: 'Stream Settings', children: [
            SettingDropdownRow(
              label: 'Resolution',
              icon: Icons.hd_outlined,
              value: pi.resolution,
              items: const ['480p', '720p', '1080p'],
              onChanged: (v) => pi.setResolution(v!),
            ),
            SettingDropdownRow(
              label: 'Frame Rate',
              icon: Icons.speed_outlined,
              value: pi.fps,
              items: const ['15 FPS', '24 FPS', '30 FPS'],
              onChanged: (v) => pi.setFps(v!),
            ),
            SettingDropdownRow(
              label: 'Bitrate',
              icon: Icons.graphic_eq,
              value: pi.bitrate,
              items: const ['1 Mbps', '2 Mbps', '4 Mbps', '8 Mbps'],
              onChanged: (v) => pi.setBitrate(v!),
            ),
          ]),

          const SizedBox(height: 20),

          // ── Device Info ───────────────────────────────────────────────────
          SettingSection(title: 'Device Info', children: [
            SettingInfoRow(
              label: 'IP Address',
              value: pi.ipAddress,
              icon: Icons.router_outlined,
            ),
            SettingInfoRow(
              label: 'Stream URL',
              value: 'http://${pi.ipAddress}:${pi.streamPort}/stream',
              icon: Icons.link,
            ),
            SettingInfoRow(
              label: 'Firmware',
              value: pi.firmwareVersion,
              icon: Icons.memory_outlined,
            ),
            SettingInfoRow(
              label: 'Signal',
              value: '${pi.signalStrength}%',
              icon: Icons.wifi,
              valueColor: pi.signalStrength > 70
                  ? AppColors.accentGreen
                  : pi.signalStrength > 30
                      ? AppColors.accentYellow
                      : AppColors.accentRed,
            ),
          ]),

          const SizedBox(height: 20),

          // ── Maintenance ───────────────────────────────────────────────────
          SettingSection(title: 'Maintenance', children: [
            SettingNavRow(
              label: 'Check for Firmware Update',
              value: _checkingFirmware ? 'Checking...' : pi.firmwareVersion,
              icon: Icons.system_update_outlined,
              onTap: _checkingFirmware
                  ? () {}
                  : () => _checkFirmware(context, pi.firmwareVersion),
            ),
            SettingNavRow(
              label: _rebooting ? 'Rebooting...' : 'Reboot Pi Camera',
              icon: Icons.restart_alt,
              onTap: _rebooting ? () {} : () => _reboot(context),
            ),
          ]),

          const SizedBox(height: 32),
        ],
      ),
    );
  }

  // ── Helpers ───────────────────────────────────────────────────────────────

  Future<void> _checkFirmware(BuildContext ctx, String current) async {
    setState(() => _checkingFirmware = true);
    await Future.delayed(const Duration(seconds: 2));
    if (!mounted) return;
    setState(() => _checkingFirmware = false);
    ScaffoldMessenger.of(ctx).showSnackBar(SnackBar(
      content: Text('Firmware $current is up to date'),
    ));
  }

  Future<void> _reboot(BuildContext ctx) async {
    setState(() => _rebooting = true);
    await Future.delayed(const Duration(seconds: 3));
    if (!mounted) return;
    setState(() => _rebooting = false);
    ScaffoldMessenger.of(ctx).showSnackBar(const SnackBar(
      content: Text('Pi Camera rebooted successfully'),
    ));
  }
}

// ── Scan Line Painter (reused from camera_screen.dart) ────────────────────────
class _ScanLinePainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Colors.white.withOpacity(0.03)
      ..strokeWidth = 1;
    for (double y = 0; y < size.height; y += 4) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
    final bracketPaint = Paint()
      ..color = Colors.white.withOpacity(0.15)
      ..strokeWidth = 2
      ..style = PaintingStyle.stroke;
    const len = 20.0;
    final cx = size.width / 2;
    final cy = size.height / 2;
    final bx = cx - 40;
    final by = cy - 40;
    canvas.drawLine(Offset(bx, by), Offset(bx + len, by), bracketPaint);
    canvas.drawLine(Offset(bx, by), Offset(bx, by + len), bracketPaint);
    canvas.drawLine(
        Offset(bx + 80, by), Offset(bx + 80 - len, by), bracketPaint);
    canvas.drawLine(
        Offset(bx + 80, by), Offset(bx + 80, by + len), bracketPaint);
    canvas.drawLine(
        Offset(bx, by + 80), Offset(bx + len, by + 80), bracketPaint);
    canvas.drawLine(
        Offset(bx, by + 80), Offset(bx, by + 80 - len), bracketPaint);
    canvas.drawLine(
        Offset(bx + 80, by + 80), Offset(bx + 80 - len, by + 80), bracketPaint);
    canvas.drawLine(
        Offset(bx + 80, by + 80), Offset(bx + 80, by + 80 - len), bracketPaint);
  }

  @override
  bool shouldRepaint(_ScanLinePainter old) => false;
}
