import 'dart:async';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import '../../core/app_colors.dart';
import '../../services/pi_service.dart';

class PiLiveScreen extends StatefulWidget {
  const PiLiveScreen({super.key});

  @override
  State<PiLiveScreen> createState() => _PiLiveScreenState();
}

class _PiLiveScreenState extends State<PiLiveScreen> {
  Uint8List? _frameBytes;
  bool _loading = true;
  bool _error = false;
  bool _running = true;
  int _fps = 0;
  int _frameCount = 0;
  DateTime _lastFpsTime = DateTime.now();
  StreamSubscription? _sub;

  @override
  void initState() {
    super.initState();
    _startStream();
  }

  @override
  void dispose() {
    _running = false;
    _sub?.cancel();
    super.dispose();
  }

  // ── Save Snapshot ──────────────────────────
  Future<void> _captureSnapshot() async {
    if (_frameBytes == null) return;

    try {
      // Show feedback
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: const Row(children: [
            Icon(Icons.check_circle, color: Colors.white, size: 16),
            SizedBox(width: 8),
            Text('Snapshot saved!'),
          ]),
          backgroundColor: AppColors.accentGreen,
          duration: const Duration(seconds: 2),
          behavior: SnackBarBehavior.floating,
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        ),
      );

      // Save to Pi via API
      await PiService.saveSnapshot();
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Failed: $e'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  // ── MJPEG Stream Parser ────────────────────────
  Future<void> _startStream() async {
    setState(() {
      _loading = true;
      _error = false;
    });

    try {
      final url = PiService.streamUrl;
      final client = http.Client();
      final req = http.Request('GET', Uri.parse(url));
      final res = await client.send(req).timeout(const Duration(seconds: 10));

      if (res.statusCode != 200) {
        setState(() {
          _error = true;
          _loading = false;
        });
        return;
      }

      setState(() => _loading = false);

      // Parse MJPEG stream
      List<int> buffer = [];

      _sub = res.stream.listen(
        (chunk) {
          if (!_running) return;
          buffer.addAll(chunk);

          // Find JPEG boundaries
          while (true) {
            final start = _indexOf(buffer, [0xFF, 0xD8]);
            final end = _indexOf(buffer, [0xFF, 0xD9]);

            if (start == -1 || end == -1 || end <= start) break;

            final jpeg = buffer.sublist(start, end + 2);
            buffer = buffer.sublist(end + 2);

            if (mounted && _running) {
              setState(() {
                _frameBytes = Uint8List.fromList(jpeg);
                _frameCount++;
              });

              // FPS counter
              final now = DateTime.now();
              final diff = now.difference(_lastFpsTime).inMilliseconds;
              if (diff >= 1000) {
                setState(() {
                  _fps = (_frameCount * 1000 / diff).round();
                  _frameCount = 0;
                  _lastFpsTime = now;
                });
              }
            }
          }
        },
        onError: (_) {
          if (mounted) setState(() => _error = true);
        },
        onDone: () {
          if (mounted && _running) {
            // Auto reconnect after 2 seconds
            Future.delayed(const Duration(seconds: 2), _startStream);
          }
        },
      );
    } catch (e) {
      if (mounted) {
        setState(() {
          _error = true;
          _loading = false;
        });
      }
    }
  }

  int _indexOf(List<int> data, List<int> pattern) {
    for (int i = 0; i <= data.length - pattern.length; i++) {
      bool found = true;
      for (int j = 0; j < pattern.length; j++) {
        if (data[i + j] != pattern[j]) {
          found = false;
          break;
        }
      }
      if (found) return i;
    }
    return -1;
  }

  void _retry() {
    _sub?.cancel();
    _startStream();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: Colors.white, size: 20),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text('Live Camera',
            style: TextStyle(
                color: Colors.white,
                fontSize: 18,
                fontWeight: FontWeight.bold)),
        actions: [
          // FPS indicator
          if (!_loading && !_error)
            Center(
              child: Container(
                margin: const EdgeInsets.only(right: 8),
                padding:
                    const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: AppColors.accentGreen.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(20),
                  border:
                      Border.all(color: AppColors.accentGreen.withOpacity(0.4)),
                ),
                child: Text('$_fps FPS',
                    style: TextStyle(
                        color: AppColors.accentGreen,
                        fontSize: 12,
                        fontWeight: FontWeight.bold)),
              ),
            ),
          // Retry button
          IconButton(
            icon: const Icon(Icons.refresh, color: Colors.white54, size: 20),
            onPressed: _retry,
          ),
        ],
      ),
      body: Column(
        children: [
          // ── STREAM VIEW ───────────────────────────
          Expanded(
            child: _loading
                ? _buildLoading()
                : _error
                    ? _buildError()
                    : _buildStream(),
          ),

          // ── BOTTOM STATUS BAR ─────────────────────
          if (!_loading && !_error) _buildStatusBar(),
        ],
      ),
    );
  }

  // ── Stream Widget ──────────────────────────────
  Widget _buildStream() {
    if (_frameBytes == null) {
      return _buildLoading();
    }
    return Stack(
      children: [
        // Frame
        Center(
          child: Image.memory(
            _frameBytes!,
            gaplessPlayback: true,
            fit: BoxFit.contain,
            width: double.infinity,
          ),
        ),

        // LIVE badge
        Positioned(
          top: 16,
          left: 16,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
            decoration: BoxDecoration(
              color: Colors.red,
              borderRadius: BorderRadius.circular(6),
            ),
            child: Row(children: [
              Container(
                width: 6,
                height: 6,
                decoration: const BoxDecoration(
                  color: Colors.white,
                  shape: BoxShape.circle,
                ),
              ),
              const SizedBox(width: 6),
              const Text('LIVE',
                  style: TextStyle(
                      color: Colors.white,
                      fontSize: 11,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 1)),
            ]),
          ),
        ),

        // ── Capture Button ─────────────────────────
        Positioned(
          bottom: 20,
          left: 0,
          right: 0,
          child: Center(
            child: GestureDetector(
              onTap: _captureSnapshot,
              child: Container(
                width: 70,
                height: 70,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: Colors.white.withOpacity(0.15),
                  border: Border.all(color: Colors.white, width: 3),
                ),
                child: Container(
                  margin: const EdgeInsets.all(8),
                  decoration: const BoxDecoration(
                    shape: BoxShape.circle,
                    color: Colors.white,
                  ),
                  child: const Icon(Icons.camera_alt,
                      color: Colors.black, size: 28),
                ),
              ),
            ),
          ),
        ),

        // Timestamp
        Positioned(
          top: 16,
          right: 16,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
            decoration: BoxDecoration(
              color: Colors.black54,
              borderRadius: BorderRadius.circular(6),
            ),
            child: Text(
              _timestamp(),
              style: const TextStyle(
                  color: Colors.white,
                  fontSize: 11,
                  fontWeight: FontWeight.w500),
            ),
          ),
        ),
      ],
    );
  }

  // ── Loading Widget ─────────────────────────────
  Widget _buildLoading() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          SizedBox(
            width: 48,
            height: 48,
            child: CircularProgressIndicator(
              strokeWidth: 2,
              color: AppColors.accentGreen,
            ),
          ),
          const SizedBox(height: 20),
          const Text('Connecting to camera...',
              style: TextStyle(color: Colors.white54, fontSize: 14)),
          const SizedBox(height: 8),
          Text(PiService.streamUrl,
              style: const TextStyle(color: Colors.white24, fontSize: 11)),
        ],
      ),
    );
  }

  // ── Error Widget ───────────────────────────────
  Widget _buildError() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: Colors.red.withOpacity(0.1),
              shape: BoxShape.circle,
            ),
            child: const Icon(Icons.videocam_off_outlined,
                color: Colors.red, size: 48),
          ),
          const SizedBox(height: 20),
          const Text('Camera Offline',
              style: TextStyle(
                  color: Colors.white,
                  fontSize: 18,
                  fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          const Text('Cannot connect to Pi camera',
              style: TextStyle(color: Colors.white54, fontSize: 14)),
          const SizedBox(height: 8),
          Text(PiService.streamUrl,
              style: const TextStyle(color: Colors.white24, fontSize: 11)),
          const SizedBox(height: 32),
          ElevatedButton.icon(
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.accentGreen,
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12)),
            ),
            onPressed: _retry,
            icon: const Icon(Icons.refresh, color: Colors.black, size: 18),
            label: const Text('Retry',
                style: TextStyle(
                    color: Colors.black, fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }

  // ── Status Bar ─────────────────────────────────
  Widget _buildStatusBar() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
      color: const Color(0xFF0A0A0A),
      child: Row(children: [
        // Status dot
        Container(
          width: 8,
          height: 8,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: _frameBytes != null ? AppColors.accentGreen : Colors.orange,
          ),
        ),
        const SizedBox(width: 8),
        Text(
          _frameBytes != null ? 'Stream Active' : 'Buffering...',
          style: TextStyle(
              color:
                  _frameBytes != null ? AppColors.accentGreen : Colors.orange,
              fontSize: 12,
              fontWeight: FontWeight.w500),
        ),
        const Spacer(),
        const Icon(Icons.lock_outline, color: Colors.white24, size: 14),
        const SizedBox(width: 4),
        const Text('Encrypted',
            style: TextStyle(color: Colors.white24, fontSize: 12)),
        const SizedBox(width: 16),
        const Icon(Icons.videocam_outlined, color: Colors.white24, size: 14),
        const SizedBox(width: 4),
        const Text('Pi Camera',
            style: TextStyle(color: Colors.white24, fontSize: 12)),
      ]),
    );
  }

  String _timestamp() {
    final now = DateTime.now();
    return '${now.hour.toString().padLeft(2, '0')}:'
        '${now.minute.toString().padLeft(2, '0')}:'
        '${now.second.toString().padLeft(2, '0')}';
  }
}
