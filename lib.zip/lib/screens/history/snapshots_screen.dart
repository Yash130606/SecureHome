import 'package:flutter/material.dart';
import '../../core/app_colors.dart';
import '../../core/app_text.dart';
import '../../services/pi_service.dart';

class SnapshotsScreen extends StatefulWidget {
  const SnapshotsScreen({super.key});

  @override
  State<SnapshotsScreen> createState() =>
    _SnapshotsScreenState();
}

class _SnapshotsScreenState
    extends State<SnapshotsScreen> {
  List<dynamic> _snapshots = [];
  bool          _loading   = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    final data = await PiService.getSnapshots();
    setState(() {
      _snapshots = data;
      _loading   = false;
    });
  }

  Future<void> _delete(String filename) async {
    final ok = await PiService.deleteSnapshot(filename);
    if (ok) {
      setState(() =>
        _snapshots.removeWhere(
          (s) => s['filename'] == filename));
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: const Text('Snapshot deleted'),
            backgroundColor: AppColors.accentGreen,
            behavior: SnackBarBehavior.floating,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10)),
          ),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bg,
      appBar: AppBar(
        backgroundColor: AppColors.bg,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios,
            color: Colors.white, size: 20),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text('Snapshots',
          style: TextStyle(color: Colors.white,
            fontWeight: FontWeight.bold)),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh,
              color: Colors.white54),
            onPressed: _load,
          ),
        ],
      ),
      body: _loading
        ? const Center(child: CircularProgressIndicator())
        : _snapshots.isEmpty
          ? _buildEmpty()
          : RefreshIndicator(
              onRefresh: _load,
              child: GridView.builder(
                padding: const EdgeInsets.all(16),
                gridDelegate:
                  const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2,
                    crossAxisSpacing: 12,
                    mainAxisSpacing: 12,
                    childAspectRatio: 0.85,
                  ),
                itemCount: _snapshots.length,
                itemBuilder: (_, i) =>
                  _SnapshotCard(
                    snapshot: _snapshots[i],
                    onDelete: () => _delete(
                      _snapshots[i]['filename']),
                    onTap: () => _showFullImage(
                      context, _snapshots[i]),
                  ),
              ),
            ),
    );
  }

  void _showFullImage(
      BuildContext ctx, Map<String, dynamic> snap) {
    Navigator.push(ctx, MaterialPageRoute(
      builder: (_) => _FullImageScreen(snapshot: snap)));
  }

  Widget _buildEmpty() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.photo_library_outlined,
            color: AppColors.textMuted, size: 64),
          const SizedBox(height: 16),
          Text('No snapshots yet', style: AppText.h2()),
          const SizedBox(height: 8),
          Text('Snapshots appear here when\nPi detects activity',
            style: AppText.bodyM(color: AppColors.textMuted),
            textAlign: TextAlign.center),
          const SizedBox(height: 24),
          ElevatedButton.icon(
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.brand,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12)),
              padding: const EdgeInsets.symmetric(
                horizontal: 20, vertical: 12)),
            onPressed: _load,
            icon: const Icon(Icons.refresh,
              color: Colors.white, size: 18),
            label: const Text('Refresh',
              style: TextStyle(color: Colors.white,
                fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }
}

// ─────────────────────────────────────────────
// SNAPSHOT CARD
// ─────────────────────────────────────────────

class _SnapshotCard extends StatelessWidget {
  final Map<String, dynamic> snapshot;
  final VoidCallback onDelete;
  final VoidCallback onTap;

  const _SnapshotCard({
    required this.snapshot,
    required this.onDelete,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final url      = PiService.snapshotUrl(
      snapshot['filename']);
    final time     = snapshot['time']     ?? '';
    final date     = snapshot['date']     ?? '';
    final type     = snapshot['type']     ?? 'snapshot';
    final sizeKb   = snapshot['size_kb']  ?? 0;
    final isPerson = type == 'person';

    return GestureDetector(
      onTap: onTap,
      child: Container(
        decoration: BoxDecoration(
          color: AppColors.bgSurface,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: isPerson
              ? Colors.red.withOpacity(0.3)
              : AppColors.border),
        ),
        child: Column(
          children: [
            // Image
            Expanded(
              child: ClipRRect(
                borderRadius: const BorderRadius.vertical(
                  top: Radius.circular(14)),
                child: Stack(
                  fit: StackFit.expand,
                  children: [
                    Image.network(
                      url,
                      fit: BoxFit.cover,
                      loadingBuilder: (_, child, progress) {
                        if (progress == null) return child;
                        return Container(
                          color: AppColors.bg,
                          child: const Center(
                            child: CircularProgressIndicator(
                              strokeWidth: 2)),
                        );
                      },
                      errorBuilder: (_, __, ___) => Container(
                        color: AppColors.bg,
                        child: const Icon(Icons.broken_image,
                          color: Colors.grey, size: 32)),
                    ),

                    // Type badge
                    Positioned(
                      top: 8, left: 8,
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 7, vertical: 3),
                        decoration: BoxDecoration(
                          color: isPerson
                            ? Colors.red
                            : AppColors.brand,
                          borderRadius:
                            BorderRadius.circular(6)),
                        child: Text(
                          isPerson ? 'PERSON' : 'SNAPSHOT',
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 8,
                            fontWeight: FontWeight.bold,
                            letterSpacing: 0.5)),
                      ),
                    ),

                    // Delete button
                    Positioned(
                      top: 6, right: 6,
                      child: GestureDetector(
                        onTap: onDelete,
                        child: Container(
                          padding: const EdgeInsets.all(4),
                          decoration: BoxDecoration(
                            color: Colors.black54,
                            borderRadius:
                              BorderRadius.circular(6)),
                          child: const Icon(Icons.delete_outline,
                            color: Colors.white, size: 16),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),

            // Info
            Padding(
              padding: const EdgeInsets.all(8),
              child: Row(children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment:
                      CrossAxisAlignment.start,
                    children: [
                      Text(time,
                        style: AppText.bodyM().copyWith(
                          fontWeight: FontWeight.w600,
                          fontSize: 13)),
                      Text('$date · ${sizeKb}KB',
                        style: AppText.bodyS(
                          color: AppColors.textMuted)),
                    ],
                  ),
                ),
                Icon(Icons.open_in_full,
                  color: AppColors.textMuted, size: 14),
              ]),
            ),
          ],
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────
// FULL IMAGE SCREEN
// ─────────────────────────────────────────────

class _FullImageScreen extends StatelessWidget {
  final Map<String, dynamic> snapshot;
  const _FullImageScreen({required this.snapshot});

  @override
  Widget build(BuildContext context) {
    final url  = PiService.snapshotUrl(snapshot['filename']);
    final time = snapshot['time'] ?? '';
    final date = snapshot['date'] ?? '';

    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios,
            color: Colors.white, size: 20),
          onPressed: () => Navigator.pop(context),
        ),
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(time,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 16,
                fontWeight: FontWeight.bold)),
            Text(date,
              style: const TextStyle(
                color: Colors.white54, fontSize: 12)),
          ],
        ),
      ),
      body: Center(
        child: InteractiveViewer(
          child: Image.network(
            url,
            fit: BoxFit.contain,
            loadingBuilder: (_, child, progress) {
              if (progress == null) return child;
              return const CircularProgressIndicator();
            },
            errorBuilder: (_, __, ___) => const Icon(
              Icons.broken_image,
              color: Colors.grey, size: 64),
          ),
        ),
      ),
    );
  }
}