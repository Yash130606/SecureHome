// lib/providers/app_provider.dart
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../core/mock_data.dart';
import '../models/camera_model.dart';
import '../models/alert_model.dart';
import '../models/recording_model.dart';
import '../services/pi_service.dart';

// ── SYSTEM ARM STATE ─────────────────────────────────────────────────────────
enum SystemArmState { disarmed, armed, night, alert, lockdown }

class AppProvider extends ChangeNotifier {
  // ── Navigation ──────────────────────────────────────────────────────────
  int _navIndex = 0;
  int get navIndex => _navIndex;
  void setNav(int i) {
    _navIndex = i;
    notifyListeners();
  }

  // ── System Arm State ─────────────────────────────────────────────────────
  SystemArmState _armState = SystemArmState.disarmed;
  SystemArmState get armState => _armState;
  DateTime? _armedAt;
  DateTime? get armedAt => _armedAt;

  void setArmState(SystemArmState state) {
    _armState = state;
    _armedAt = (state != SystemArmState.disarmed) ? DateTime.now() : null;
    notifyListeners();
  }

  bool get isArmed => _armState != SystemArmState.disarmed;

  // ── Cameras ─────────────────────────────────────────────────────────────
  late List<CameraModel> _cameras;
  List<CameraModel> get cameras => List.unmodifiable(_cameras);
  int get onlineCount => _cameras.where((c) => c.isOnline).length;
  int get totalAlerts => _cameras.fold(0, (s, c) => s + c.alerts);
  int get lowBatteryCount => _cameras.where((c) => c.isBatteryLow).length;
  int get offlineCount => _cameras.where((c) => !c.isOnline).length;

  void toggleCamera(String id, bool val) {
    final i = _cameras.indexWhere((c) => c.id == id);
    if (i != -1) {
      _cameras[i] = _cameras[i].copyWith(isOn: val);
      notifyListeners();
    }
  }

  void updateCamera(String id, CameraModel updated) {
    final i = _cameras.indexWhere((c) => c.id == id);
    if (i != -1) {
      _cameras[i] = updated;
      notifyListeners();
    }
  }

  void addCamera(CameraModel cam) {
    _cameras.add(cam);
    notifyListeners();
  }

  void removeCamera(String id) {
    _cameras.removeWhere((c) => c.id == id);
    _alerts.removeWhere((a) =>
        a.camera ==
        _cameras
            .firstWhere((c) => c.id == id, orElse: () => _cameras.first)
            .name);
    notifyListeners();
  }

  List<String> get zoneNames {
    final zones = _cameras.map((c) => c.zone).toSet().toList()..sort();
    return zones;
  }

  // ── Alerts ───────────────────────────────────────────────────────────────
  late List<AlertModel> _alerts;
  List<AlertModel> get alerts => List.unmodifiable(_alerts);
  int get unreadCount => _alerts.where((a) => !a.isRead).length;

  List<AlertModel> alertsByType(String type) => type == 'All'
      ? List.unmodifiable(_alerts)
      : List.unmodifiable(_alerts.where((a) => a.type == type.toLowerCase()));

  int alertCountByType(String type) => type == 'All'
      ? _alerts.length
      : _alerts.where((a) => a.type == type.toLowerCase()).length;

  void markRead(String id) {
    final i = _alerts.indexWhere((a) => a.id == id);
    if (i != -1) {
      _alerts[i] = _alerts[i].copyWith(isRead: true);
      notifyListeners();
    }
  }

  void markAllRead() {
    _alerts = _alerts.map((a) => a.copyWith(isRead: true)).toList();
    notifyListeners();
  }

  void dismissAlert(String id) {
    _alerts.removeWhere((a) => a.id == id);
    notifyListeners();
  }

  void clearAllAlerts() {
    _alerts.clear();
    notifyListeners();
  }

  void _injectAlert(AlertModel alert) {
    _alerts.insert(0, alert);
    notifyListeners();
  }

  // ── Recordings ────────────────────────────────────────────────────────────
  late List<RecordingModel> _recordings;
  List<RecordingModel> get recordings => List.unmodifiable(_recordings);

  String _recordingCameraFilter = 'All';
  String _recordingTypeFilter = 'All';
  String get recordingCameraFilter => _recordingCameraFilter;
  String get recordingTypeFilter => _recordingTypeFilter;

  List<RecordingModel> get filteredRecordings {
    var list = _recordings.toList();
    if (_recordingCameraFilter != 'All') {
      list = list.where((r) => r.cameraId == _recordingCameraFilter).toList();
    }
    if (_recordingTypeFilter != 'All') {
      list = list
          .where((r) => r.type == _recordingTypeFilter.toLowerCase())
          .toList();
    }
    return list;
  }

  void setRecordingCameraFilter(String f) {
    _recordingCameraFilter = f;
    notifyListeners();
  }

  void setRecordingTypeFilter(String f) {
    _recordingTypeFilter = f;
    notifyListeners();
  }

  String get recordingFilter => _recordingCameraFilter;
  void setRecordingFilter(String f) => setRecordingCameraFilter(f);

  void toggleFavourite(String id) {
    final i = _recordings.indexWhere((r) => r.id == id);
    if (i != -1) {
      _recordings[i] =
          _recordings[i].copyWith(isFavourite: !_recordings[i].isFavourite);
      notifyListeners();
    }
  }

  void deleteRecording(String id) {
    _recordings.removeWhere((r) => r.id == id);
    notifyListeners();
  }

  List<String> get cameraNames => ['All', ..._cameras.map((c) => c.name)];
  List<String> get cameraIds => ['All', ..._cameras.map((c) => c.id)];

  Map<String, List<RecordingModel>> get recordingsByDay {
    final map = <String, List<RecordingModel>>{};
    for (final r in filteredRecordings) {
      final day = '${r.timestamp.year}-'
          '${r.timestamp.month.toString().padLeft(2, '0')}-'
          '${r.timestamp.day.toString().padLeft(2, '0')}';
      map.putIfAbsent(day, () => []).add(r);
    }
    return map;
  }

  Map<String, List<AlertModel>> get alertsByDay {
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final yesterday = today.subtract(const Duration(days: 1));
    final map = <String, List<AlertModel>>{};
    for (final a in _alerts) {
      final alertDay =
          DateTime(a.timestamp.year, a.timestamp.month, a.timestamp.day);
      String key;
      if (alertDay == today) {
        key = 'Today';
      } else if (alertDay == yesterday) {
        key = 'Yesterday';
      } else {
        key = '${a.timestamp.day} ${_monthName(a.timestamp.month)}';
      }
      map.putIfAbsent(key, () => []).add(a);
    }
    return map;
  }

  String _monthName(int m) {
    const months = [
      '',
      'Jan',
      'Feb',
      'Mar',
      'Apr',
      'May',
      'Jun',
      'Jul',
      'Aug',
      'Sep',
      'Oct',
      'Nov',
      'Dec'
    ];
    return months[m];
  }

  // ── User Profile ──────────────────────────────────────────────────────────
  String userName = kUserProfile['name']!;
  String userEmail = kUserProfile['email']!;
  String userPlan = kUserProfile['plan']!;
  String userMemberSince = kUserProfile['memberSince']!;
  String userAvatar = kUserProfile['avatar']!;

  void updateProfile({String? name, String? email}) {
    if (name != null) userName = name;
    if (email != null) userEmail = email;
    notifyListeners();
  }

  // ── Notification Prefs ────────────────────────────────────────────────────
  bool notifMotion = true;
  bool notifPerson = true;
  bool notifSystem = true;
  bool doNotDisturb = false;
  String notifSound = 'Default';
  String notifVibration = 'On';
  String notifBannerStyle = 'Temporary';
  String notifSensitivity = 'High';
  int notifCooldownSeconds = 60;
  String notifEmail = '';
  TimeOfDay? quietHoursStart;
  TimeOfDay? quietHoursEnd;

  void toggleNotif(String key, bool v) {
    switch (key) {
      case 'motion':
        notifMotion = v;
        break;
      case 'person':
        notifPerson = v;
        break;
      case 'system':
        notifSystem = v;
        break;
      case 'dnd':
        doNotDisturb = v;
        break;
    }
    notifyListeners();
  }

  void setNotifSound(String v) {
    notifSound = v;
    notifyListeners();
  }

  void setNotifVibration(String v) {
    notifVibration = v;
    notifyListeners();
  }

  void setNotifSensitivity(String v) {
    notifSensitivity = v;
    notifyListeners();
  }

  void setNotifCooldown(int v) {
    notifCooldownSeconds = v;
    notifyListeners();
  }

  void setNotifEmail(String v) {
    notifEmail = v;
    notifyListeners();
  }

  void setQuietHours(TimeOfDay? s, TimeOfDay? e) {
    quietHoursStart = s;
    quietHoursEnd = e;
    notifyListeners();
  }

  // ── Onboarding ────────────────────────────────────────────────────────────
  bool _onboardingDone = false;
  bool get onboardingDone => _onboardingDone;

  Future<void> completeOnboarding() async {
    _onboardingDone = true;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('onboarding_done', true);
    notifyListeners();
  }

  // ── Error State ───────────────────────────────────────────────────────────
  String? _errorMessage;
  String? get errorMessage => _errorMessage;
  void clearError() {
    _errorMessage = null;
    notifyListeners();
  }

  // ── Alert Simulation Timer ────────────────────────────────────────────────
  Timer? _alertTimer;
  int _alertCounter = 100;

  void startAlertSimulation() {
    _alertTimer?.cancel();
    _alertTimer = Timer.periodic(const Duration(seconds: 45), (_) {
      if (!doNotDisturb) {
        _alertCounter++;
        final now = DateTime.now();
        final types = ['motion', 'person'];
        final cams = _cameras.where((c) => c.isOnline).toList();
        if (cams.isEmpty) return;
        final cam = cams[_alertCounter % cams.length];
        final type = types[_alertCounter % types.length];
        _injectAlert(AlertModel(
          id: 'sim_$_alertCounter',
          type: type,
          title: type == 'person' ? 'Person Detected' : 'Motion Detected',
          subtitle:
              '${type == 'person' ? 'AI detected a person' : 'Movement detected'} at ${cam.name}',
          camera: cam.name,
          time: 'Just now',
          isRead: false,
          zone: cam.zone,
          severity: type == 'person' ? 'high' : 'medium',
          timestamp: now,
        ));
      }
    });
  }

  void stopAlertSimulation() => _alertTimer?.cancel();

  // ── Pi State ──────────────────────────────────────────────────────────────
  bool _piArmed = false;
  bool _piNightMode = false;
  bool _piRunning = false;
  int _piUnknowns = 0;
  bool _piConnected = false;
  List<dynamic> _piAlerts = [];

  bool get piArmed => _piArmed;
  bool get piNightMode => _piNightMode;
  bool get piRunning => _piRunning;
  int get piUnknowns => _piUnknowns;
  bool get piConnected => _piConnected;
  List<dynamic> get piAlerts => _piAlerts;

  // ── Connect to Pi ─────────────────────────────────────────────────────────
  Future<bool> connectToPi(String ip) async {
    PiService.setIp(ip);
    final ok = await PiService.checkHealth();
    _piConnected = ok;
    if (ok) {
      await refreshFromPi();
    }
    notifyListeners();
    return ok;
  }

  // ── Refresh Data from Pi ──────────────────────────────────────────────────
  Future<void> refreshFromPi() async {
    try {
      final status = await PiService.getStatus();
      if (status.isNotEmpty) {
        _piArmed = status['armed'] ?? false;
        _piNightMode = status['night_mode'] ?? false;
        _piRunning = status['running'] ?? false;
        _piUnknowns = status['unknown_count'] ?? 0;
        notifyListeners();
      }

      final alerts = await PiService.getAlerts();
      if (alerts.isNotEmpty) {
        _piAlerts = alerts;
        notifyListeners();
      }
    } catch (_) {}
  }

  // ── Toggle Arm from App ───────────────────────────────────────────────────
  Future<void> togglePiArm() async {
    final newState = !_piArmed;
    final ok = await PiService.setArmed(newState);
    if (ok) {
      _piArmed = newState;
      setArmState(newState ? SystemArmState.armed : SystemArmState.disarmed);
      notifyListeners();
    }
  }

  // ── Toggle Night Mode from App ────────────────────────────────────────────
  Future<void> togglePiNightMode() async {
    final newState = !_piNightMode;
    final ok = await PiService.setNightMode(newState);
    if (ok) {
      _piNightMode = newState;
      // ── FIX: update armState in both directions ──
      setArmState(newState ? SystemArmState.night : SystemArmState.disarmed);
      notifyListeners();
    }
  }

  // ── Start / Stop Detection from App ──────────────────────────────────────
  Future<void> startPiDetection() async {
    final ok = await PiService.startDetection();
    if (ok) {
      _piRunning = true;
      notifyListeners();
    }
  }

  Future<void> stopPiDetection() async {
    final ok = await PiService.stopDetection();
    if (ok) {
      _piRunning = false;
      notifyListeners();
    }
  }

  // ── Load Prefs ────────────────────────────────────────────────────────────
  Future<void> loadPrefs() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      _onboardingDone = prefs.getBool('onboarding_done') ?? false;
      notifyListeners();
    } catch (e) {
      _errorMessage = 'Failed to load preferences';
      notifyListeners();
    }
  }

  // ── Constructor ───────────────────────────────────────────────────────────
  AppProvider() {
    _cameras = kCameras
        .map((m) => CameraModel.fromMap(Map<String, dynamic>.from(m)))
        .toList();
    _alerts = kAlerts
        .map((m) => AlertModel.fromMap(Map<String, dynamic>.from(m)))
        .toList();
    _recordings = kRecordings
        .map((m) => RecordingModel.fromMap(Map<String, dynamic>.from(m)))
        .toList();
    loadPrefs();
    startAlertSimulation();
  }

  // ── Logout ────────────────────────────────────────────────────────────────
  Future<void> logout() async {
    _armState = SystemArmState.disarmed;
    _armedAt = null;
    _navIndex = 0;
    _piArmed = false;
    _piNightMode = false;
    _piRunning = false;
    _piConnected = false;
    _piAlerts = [];
    _alerts.clear();
    _recordingCameraFilter = 'All';
    _recordingTypeFilter = 'All';
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.remove('onboarding_done');
    } catch (_) {}
    notifyListeners();
  }

  @override
  void dispose() {
    _alertTimer?.cancel();
    super.dispose();
  }
}
