import 'dart:convert';
import 'package:http/http.dart' as http;

class PiService {
  static String _baseUrl = '';

  // ── Set Pi IP ────────────────────────────────────
  static void setIp(String ip) {
    _baseUrl = 'http://$ip:5000';
  }

  static String get streamUrl => '$_baseUrl/api/stream';
  static String get baseUrl => _baseUrl;

  // ── Health Check ─────────────────────────────────
  static Future<bool> checkHealth() async {
    try {
      final res = await http
          .get(
            Uri.parse('$_baseUrl/api/health'),
          )
          .timeout(const Duration(seconds: 5));
      return res.statusCode == 200;
    } catch (_) {
      return false;
    }
  }

  // ── Get Status ───────────────────────────────────
  static Future<Map<String, dynamic>> getStatus() async {
    try {
      final res = await http
          .get(
            Uri.parse('$_baseUrl/api/status'),
          )
          .timeout(const Duration(seconds: 5));
      if (res.statusCode == 200) {
        return jsonDecode(res.body);
      }
    } catch (_) {}
    return {};
  }

  // ── Arm / Disarm ─────────────────────────────────
  static Future<bool> setArmed(bool armed) async {
    try {
      final res = await http
          .post(
            Uri.parse('$_baseUrl/api/arm'),
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode({'armed': armed}),
          )
          .timeout(const Duration(seconds: 5));
      return res.statusCode == 200;
    } catch (_) {
      return false;
    }
  }

  // ── Night Mode ───────────────────────────────────
  static Future<bool> setNightMode(bool enabled) async {
    try {
      final res = await http
          .post(
            Uri.parse('$_baseUrl/api/nightmode'),
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode({'enabled': enabled}),
          )
          .timeout(const Duration(seconds: 5));
      return res.statusCode == 200;
    } catch (_) {
      return false;
    }
  }

  // ── Get Alerts ───────────────────────────────────
  static Future<List<dynamic>> getAlerts() async {
    try {
      final res = await http
          .get(
            Uri.parse('$_baseUrl/api/alerts'),
          )
          .timeout(const Duration(seconds: 5));
      if (res.statusCode == 200) {
        return jsonDecode(res.body);
      }
    } catch (_) {}
    return [];
  }

  // ── Clear Alerts ─────────────────────────────────
  static Future<bool> clearAlerts() async {
    try {
      final res = await http
          .post(
            Uri.parse('$_baseUrl/api/alerts/clear'),
          )
          .timeout(const Duration(seconds: 5));
      return res.statusCode == 200;
    } catch (_) {
      return false;
    }
  }

  // ── Get Known Faces ──────────────────────────────
  static Future<List<dynamic>> getKnownFaces() async {
    try {
      final res = await http
          .get(
            Uri.parse('$_baseUrl/api/faces'),
          )
          .timeout(const Duration(seconds: 5));
      if (res.statusCode == 200) {
        return jsonDecode(res.body);
      }
    } catch (_) {}
    return [];
  }

  // ── Delete Face ──────────────────────────────────
  static Future<bool> deleteFace(String name) async {
    try {
      final res = await http
          .delete(
            Uri.parse('$_baseUrl/api/faces/$name'),
          )
          .timeout(const Duration(seconds: 5));
      return res.statusCode == 200;
    } catch (_) {
      return false;
    }
  }

  // ── Get Logs ─────────────────────────────────────
  static Future<List<dynamic>> getLogs() async {
    try {
      final res = await http
          .get(
            Uri.parse('$_baseUrl/api/logs'),
          )
          .timeout(const Duration(seconds: 5));
      if (res.statusCode == 200) {
        return jsonDecode(res.body);
      }
    } catch (_) {}
    return [];
  }

  // ── Start Detection ──────────────────────────────
  static Future<bool> startDetection() async {
    try {
      final res = await http
          .post(
            Uri.parse('$_baseUrl/api/detection/start'),
          )
          .timeout(const Duration(seconds: 5));
      return res.statusCode == 200;
    } catch (_) {
      return false;
    }
  }

  // ── Stop Detection ───────────────────────────────
  static Future<bool> stopDetection() async {
    try {
      final res = await http
          .post(
            Uri.parse('$_baseUrl/api/detection/stop'),
          )
          .timeout(const Duration(seconds: 5));
      return res.statusCode == 200;
    } catch (_) {
      return false;
    }
  }

  // ── Get Unknown Faces ────────────────────────────
  static Future<List<dynamic>> getUnknowns() async {
    try {
      final res = await http
          .get(
            Uri.parse('$_baseUrl/api/unknowns'),
          )
          .timeout(const Duration(seconds: 5));
      if (res.statusCode == 200) {
        return jsonDecode(res.body);
      }
    } catch (_) {}
    return [];
  }

  // ── Get Zone Config ──────────────────────────────
  static Future<Map<String, dynamic>> getZone() async {
    try {
      final res = await http
          .get(
            Uri.parse('$_baseUrl/api/zone'),
          )
          .timeout(const Duration(seconds: 5));
      if (res.statusCode == 200) {
        return jsonDecode(res.body);
      }
    } catch (_) {}
    return {};
  }

  // ── Save Snapshot ─────────────────────────
  static Future<bool> saveSnapshot() async {
    try {
      final res = await http
          .post(
            Uri.parse('$_baseUrl/api/snapshot'),
          )
          .timeout(const Duration(seconds: 5));
      return res.statusCode == 200;
    } catch (_) {
      return false;
    }
  }

  // ── Get Snapshots ─────────────────────────
  static Future<List<dynamic>> getSnapshots() async {
    try {
      final res = await http
          .get(
            Uri.parse('$_baseUrl/api/snapshots'),
          )
          .timeout(const Duration(seconds: 5));
      if (res.statusCode == 200) {
        return jsonDecode(res.body);
      }
    } catch (_) {}
    return [];
  }

// ── Snapshot Image URL ────────────────────
  static String snapshotUrl(String filename) =>
      '$_baseUrl/api/snapshots/$filename';

// ── Delete Snapshot ───────────────────────
  static Future<bool> deleteSnapshot(String filename) async {
    try {
      final res = await http
          .delete(
            Uri.parse('$_baseUrl/api/snapshots/$filename'),
          )
          .timeout(const Duration(seconds: 5));
      return res.statusCode == 200;
    } catch (_) {
      return false;
    }
  }

  // ── Latest frame thumbnail URL ────────────────────
  static String get thumbnailUrl => '$_baseUrl/api/snapshot/latest';
}
